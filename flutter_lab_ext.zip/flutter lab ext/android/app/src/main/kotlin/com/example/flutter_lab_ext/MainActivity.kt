package com.example.flutter_lab_ext

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
